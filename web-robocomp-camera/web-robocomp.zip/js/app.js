const communicator = Ice.initialize();
const proxy = communicator.stringToProxy("omnirobot:ws -h 158.49.247.121 -p 9000");

getBaseState();

async function getBaseState() {
    try {
        //
        // Create a proxy for the hello object
        //
        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.setSpeedBase(100, 0, 0)
            .then(result => {
                console.log(result);
                document.getElementById("status").value = result;
            });
    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}

async function moveUp() {
    try {
        //
        // Create a proxy for the hello object
        //

        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.setSpeedBase(+ document.getElementById("speedZ").value, document.getElementById("speedX").value, document.getElementById("steer").value);

        setTimeout(function () { test.stopBase(); }, 500);

    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}

async function moveDown() {
    try {
        //
        // Create a proxy for the hello object
        //

        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.setSpeedBase(- document.getElementById("speedZ").value, document.getElementById("speedX").value, document.getElementById("steer").value);

        setTimeout(function () { test.stopBase(); }, 500);
    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}

async function moveLeft() {
    try {
        //
        // Create a proxy for the hello object
        //

        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.setSpeedBase(document.getElementById("speedZ").value, + document.getElementById("speedX").value, document.getElementById("steer").value);

        setTimeout(function () { test.stopBase(); }, 500);
    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}

async function moveRight() {
    try {
        //
        // Create a proxy for the hello object
        //

        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.setSpeedBase(document.getElementById("speedZ").value, - document.getElementById("speedX").value, document.getElementById("steer").value);

        setTimeout(function () { test.stopBase(); }, 500);
    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}

async function stop() {
    try {
        //
        // Create a proxy for the hello object
        //

        const test = await RoboCompOmniRobot.OmniRobotPrx.checkedCast(proxy);

        await test.stopBase();
    }
    catch (ex) {
        console.log(ex.toString());
    }
    finally {
        // if (communicator) {
        //     return communicator.destroy();
        // }
    }
}